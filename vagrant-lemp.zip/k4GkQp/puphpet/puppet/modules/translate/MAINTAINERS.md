## Maintenance

Maintainers:
  - Puppet Forge Modules Team `forge-modules |at| puppet |dot| com`

Tickets: https://tickets.puppet.com/browse/MODULES. Make sure to set component to `translate`.

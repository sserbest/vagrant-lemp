# Dumb augeasprovider type

Puppet::Type.newtype(:augeasprovider) do
  @doc = 'Dumb Augeas provider type'
end

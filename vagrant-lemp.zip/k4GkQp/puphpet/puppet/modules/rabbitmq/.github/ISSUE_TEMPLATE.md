<!--
Thank you for contributing to this project!

- This project has a Contributor Code of Conduct: https://voxpupuli.org/coc/
- Please check that here is no existing issue or PR that addresses your problem.
- Please fill the following form to enable us to help you.
- Our vulnerabilities reporting process is at https://voxpupuli.org/security/

-->

## Affected Puppet, Ruby, OS and module versions/distributions

- Puppet:
- Ruby:
- Distribution:
- Module version:

## How to reproduce (e.g Puppet code you use)

## What are you seeing

## What behaviour did you expect instead

## Output log

## Any additional information you'd like to impart
